const intro = `
Nama lengkap:
Nama panggilan:
Hobi:
Umur:
Gender:
Kelas:
Tinggi badan:
Beratbadan :
Agama:
Golongan darah:
Status:
Nama pacar:
Jumlah mantan:
Nama mantan:
Nama bapak :
Nama ibu : 
Nama kakak:
Kakak online:
Kakak kandung :
Jumlah kakak:
Nama adek:
Adek online:
Adek kandung :
Jumlah adek:
Nama kakek:
Kakek dari ayah :
Kakek dari ibu :
Nama nenek:
Nenek dari ayah :
Nenek dari ibu :
Nama bibi:
Bibi dari ayah :
Bibi dari ibu :
Nama paman:
Paman dari ayah :
Paman dari ibu :
KTP:
SIM:
STNK:
BPKB:
KK:
Alamat rumah:
RT:
RW:
KELURAHAN:
KECAMATAN:
KABUPATEN:
KOTA:
PROVINSI:
PLANET:
GALAXY:
UNIVERSE:
LANGIT:
DARATAN:
LAUTAN:
KEPULAUAN:
SAMUDRA:
UKURAN SEPATU:
UKURAN BAJU:
UKURAN CELANA:
LEBAR PINGGANG:
PANJANG TANGAN:
PANJANG KAKI:
MAKANAN FAVORIT:
MINUMAN FAVORIT:
FILM FAVORIT:
SINETRON FAVORIT:
GAME FAVORIT:
ANIME FAVORIT:
MANGA FAVORIT:
MANHUA FAVORIT:
MANHWA FAVORIT:
CHANNEL YOUTUBE:
INSTAGRAM:
TWITTEER:
FACEBOOK:
MUSIC FAVORIT:
SIFAT:
SIKAP:
ZODIAK:
TANGGAL LAHIR:
MERK HP:
MERK MOTOR:
MERK MOBIL:
TINGKAT RUMAH:
ALAMAT SEKOLAH:
Ukuran daleman:
Ukuran atasan :
Diameter kepala :
Statistik tubuh:
Diameter perut :
Diameter lengan :
Diameter paha :
Diameter lutut :
Diameter betis:
Panjang tangan :
Panjang kaki :
Panjang kepala :
Lebar hidung :
Cita cita :
Hobi :
Jenis hewanpeliharaan :
Nama hewan:
Diameter rumah:
Waifu:
Husbu:
Loli kesukaan :
Shota kesukaan :
Punya brp teman :
Teman online :
Teman offline :
Teman main game:
Teman sekolah:
Temen rumah:
`
exports.intro = intro